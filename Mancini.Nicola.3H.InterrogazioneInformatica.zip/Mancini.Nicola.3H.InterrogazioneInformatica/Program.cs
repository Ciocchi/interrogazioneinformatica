﻿//Dato un vettore contenente i premi pagati presso un'agenzia assicurativa, stampa l'elenco dei premi compresi
//tra due valori prefissati.

using System;

namespace interrogazione_informatica
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Programma scritto da Mancini Nicola");
            
            int[] Valori = new int[10] { 200, 650, 340, 900, 378, 220, 55, 444, 721, 123 };//inizializzazo il vettore "Valori"

            int Valmin=200; //valore minimo del premio
            int ValMax=500; //valore massimo del premio
            int c=0; //contatore

            foreach(int a in Valori)
            {
                if(a>=Valmin && a<=ValMax) //confronto il vettore con Valmin e Valmax
                {
                    c++;
                    Console.WriteLine("ll premio {0} ha il valore di:{1} euro ",c,a);
                }
            }
        }
    }
}
